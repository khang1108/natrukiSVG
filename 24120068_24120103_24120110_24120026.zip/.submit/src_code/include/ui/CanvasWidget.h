// File: /include/ui/CanvasWidget.h

#ifndef UI_CANVAS_WIDGET_H
#define UI_CANVAS_WIDGET_H

#include "svg/Types.h"

#include <QImage>
#include <QPoint>
#include <QPointF>
#include <QTransform>
#include <QWidget>
#include <memory>

// --- Khai báo trước (Forward Declarations) ---
class SVGDocument;
class QPaintEvent;
class QMouseEvent;
class QWheelEvent;
class QPainter;

/**
 * @brief Widget tùy chỉnh (custom widget) dùng để hiển thị (render)
 * nội dung của một 'SVGDocument'.
 *
 * Nó cũng quản lý trạng thái camera (Pan, Zoom, Rotate, Flip).
 *
 */
class CanvasWidget : public QWidget
{
  Q_OBJECT // Macro bắt buộc

      private :
    /**
     * @brief Con trỏ thông minh "sở hữu" tài liệu SVG.
     */
    std::unique_ptr<SVGDocument>
        m_document;

    // --- CÁC BIẾN LƯU TRẠNG THÁI CAMERA (VIEW) ---
    // (Role C
    // sẽ đọc các biến này trong 'paintEvent'
    // để thiết lập QPainter)

    /**
     * @brief Mức độ phóng to (Scale). Mặc định là 1.0.
     */
    double m_scale = 1.0;

    /**
     * @brief Vị trí dịch chuyển (Pan).
     */
    QPointF m_panOffset;

    /**
     * @brief Góc xoay (tính bằng độ).
     */
    double m_rotation = 0.0;

    /**
     * @brief Cờ (flag) cho biết hình có bị lật (Flip) hay không.
     */
    bool m_isFlipped = false;
    SVGRectF m_sceneBounds{0, 0, 0, 0};
    bool m_hasSceneBounds = false;
    bool m_hasPaintedWithValidSize = false;
    double m_fitScale = 1.0;  // Initial scale to fit content in viewport
    QSize m_lastViewportSize; // Track viewport size to recalculate fitScale when it changes

  public:
    /**
     * @brief Hàm khởi tạo (Constructor).
     *
     * * - Vai trò của Role C (Implement):
     * Viết logic trong 'CanvasWidget.cpp'.
     */
    explicit CanvasWidget(QWidget* parent = nullptr);

    /**
     * @brief Hàm hủy (Destructor).
     *
     * * - Vai trò của Role C (Implement):
     * Viết logic trong 'CanvasWidget.cpp'.
     */
    virtual ~CanvasWidget();

    /**
     * @brief Hàm (setter) để 'MainWindow' nạp tài liệu SVG vào đây.
     * @param document Con trỏ thông minh đến tài liệu đã được parse.
     */
    void setDocument(std::unique_ptr<SVGDocument> document);

    /**
     * @brief Kiểm tra xem widget hiện có tài liệu để hiển thị hay không.
     */
    bool hasDocument() const;

    /**
     * @brief Lấy giá trị scale hiện tại.
     */
    double getScale() const { return m_scale; }

    /**
     * @brief Đặt giá trị scale thủ công.
     */
    void setScale(double scale);

    /**
     * @brief Kết xuất tài liệu hiện tại sang một QImage.
     * @param size Kích thước ảnh đầu ra. Nếu size rỗng sẽ dùng kích thước widget.
     */
    QImage renderToImage(const QSize& size = QSize());

    // --- CÁC HÀM (SLOTS) CÔNG KHAI ĐỂ MAINWINDOW GỌI ---
  public slots:
    /**
     * @brief Tăng mức độ phóng to.
     * * - Role C (Implement):
     * Sẽ tăng 'm_scale' (ví dụ: m_scale *= 1.2;)
     * và gọi 'update()' để vẽ lại.
     */
    void zoomIn();

    /**
     * @brief Giảm mức độ phóng to.
     * * - Role C (Implement):
     * Sẽ giảm 'm_scale' (ví dụ: m_scale /= 1.2;)
     * và gọi 'update()' để vẽ lại.
     */
    void zoomOut();

    /**
     * @brief Đặt lại 'm_scale' = 1.0 và các trạng thái khác.
     * * - Role C (Implement):
     * Sẽ reset 'm_scale', 'm_panOffset', 'm_rotation', ...
     * và gọi 'update()' để vẽ lại.
     */
    void zoomReset();

    /**
     * @brief Xoay hình (ví dụ: thêm 90 độ).
     * * - Role C (Implement):
     * Sẽ cập nhật 'm_rotation += 90;'
     * và gọi 'update()' để vẽ lại.
     */
    void rotate();

    /**
     * @brief Lật hình (ngang hoặc dọc).
     * * - Role C (Implement):
     * Sẽ thay đổi 'm_isFlipped = !m_isFlipped;'
     * và gọi 'update()' để vẽ lại.
     */
    void flip();

  protected:
    /**
     * @brief Hàm vẽ chính.
     *
     * * - Vai trò của Role C (Implement):
     * Viết logic trong 'CanvasWidget.cpp'. Logic này sẽ:
     * 1. Tạo 'QPainter'.
     * 2. ĐỌC CÁC BIẾN ('m_scale', 'm_panOffset', 'm_rotation', 'm_isFlipped')
     * và dùng chúng để thiết lập 'QPainter' (ví dụ: painter.translate(...),
     * painter.scale(...), painter.rotate(...)).
     * 3. Tạo 'QtRenderer renderer(&painter);'.
     * 4. Gọi 'm_document->draw(renderer);'.
     */
    void paintEvent(QPaintEvent* event) override;

    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;
    void wheelEvent(QWheelEvent* event) override;
    void showEvent(QShowEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;

    // * - Role C (Implement):
    // Cũng sẽ implement các hàm sự kiện (mousePress, wheelEvent)
    // để cập nhật 'm_scale' và 'm_panOffset' cho Pan/Zoom.
    //

  private:
    SVGRectF calculateDocumentBounds() const;
    QTransform buildViewTransform(const QSize& viewportSize) const;
    void renderDocument(QPainter& painter, const QSize& viewportSize);
    void clampScale();
    void updateSceneBounds();
    const SVGRectF& sceneBounds() const;
    void applyZoom(double factor, const QPointF& viewportAnchor);

    bool m_isPanning = false;
    QPoint m_lastMousePos;
};

#endif // UI_CANVAS_WIDGET_H